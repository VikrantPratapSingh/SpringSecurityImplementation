package com.truongbn.security.entities;

public enum Role {
    USER,
    ADMIN
}
